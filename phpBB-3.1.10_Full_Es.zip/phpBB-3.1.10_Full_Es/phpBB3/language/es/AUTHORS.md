phpBB 3.1 Formal Honorifics (Usted)
================================

Official Spanish Translation for phpBB 3.1 Formal Honorifics (USTED)

Traducción oficial a Español de phpBB 3.1 Formal Honorifics (USTED)

## Autores
ThE KuKa (Raúl Arroyo Monzo) - 3.0.10 to 3.1

Huan Manwë (Juan Manuel) - phpBB 3.0.x to 3.0.9

## © [phpBB España](http://www.phpbb-es.com) 2003 / 2016
